from flask import Flask, request, jsonify
import mysql.connector
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Allow cross-origin requests

# Connect to DB
def get_db_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='iiui1234',
        database='hospital_db'  # Change to your DB name
    )

# Route to get patients
@app.route('/get_patients', methods=['GET'])
def get_patients():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT * FROM patients')
    patients = cursor.fetchall()
    conn.close()
    return jsonify(patients)

# Route to add a patient
@app.route('/add_patient', methods=['POST'])
def add_patient():
    data = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        'INSERT INTO patients (id, name, age, condition) VALUES (%s, %s, %s, %s)',
        (data['id'], data['name'], data['age'], data['condition'])
    )
    conn.commit()
    conn.close()
    return jsonify({'message': 'Patient added successfully!'})

# Route to delete a patient
@app.route('/delete_patient/<int:id>', methods=['DELETE'])
def delete_patient(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM patients WHERE id = %s', (id,))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Patient deleted successfully!'})

if __name__ == '__main__':
    app.run(debug=True)
